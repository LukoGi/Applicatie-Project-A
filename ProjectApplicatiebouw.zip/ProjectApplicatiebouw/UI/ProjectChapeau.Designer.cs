﻿namespace UI
{
    partial class ProjectChapeau
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ProjectChapeau));
            this.LoginPanel = new System.Windows.Forms.Panel();
            this.ForgotPasswordLabelLoginPanel = new System.Windows.Forms.Label();
            this.LoginButtonLoginPanel = new System.Windows.Forms.Button();
            this.PasswordLabelLoginPanel = new System.Windows.Forms.Label();
            this.UsernameLabelLoginPanel = new System.Windows.Forms.Label();
            this.LoginPasswordTextBox = new System.Windows.Forms.TextBox();
            this.LoginEmployeeNumberTextBox = new System.Windows.Forms.TextBox();
            this.LogoLoginPanel = new System.Windows.Forms.PictureBox();
            this.TableStatusPanel = new System.Windows.Forms.Panel();
            this.TableNumberAnswerStatusPanel = new System.Windows.Forms.Label();
            this.GoToTableButtonTableStatusPanel = new System.Windows.Forms.Button();
            this.ReservedButtonTableStatusPanel = new System.Windows.Forms.Button();
            this.OccupiedButtonTableStatusPanel = new System.Windows.Forms.Button();
            this.FreeButtonTableStatusPanel = new System.Windows.Forms.Button();
            this.TableNumberLabelStatusPanel = new System.Windows.Forms.Label();
            this.BackButtonTableStatusPanel = new System.Windows.Forms.Button();
            this.LogoTableStatusPanel = new System.Windows.Forms.PictureBox();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.TableButton1 = new System.Windows.Forms.Button();
            this.TableButton2 = new System.Windows.Forms.Button();
            this.TableButton3 = new System.Windows.Forms.Button();
            this.TableButton4 = new System.Windows.Forms.Button();
            this.TableButton5 = new System.Windows.Forms.Button();
            this.TableButton6 = new System.Windows.Forms.Button();
            this.TableButton7 = new System.Windows.Forms.Button();
            this.TableButton8 = new System.Windows.Forms.Button();
            this.TableButton9 = new System.Windows.Forms.Button();
            this.TableButton10 = new System.Windows.Forms.Button();
            this.LogoTablePanel = new System.Windows.Forms.PictureBox();
            this.BackButtonTablePanel = new System.Windows.Forms.Button();
            this.EmployeeNameTablesPanel = new System.Windows.Forms.Label();
            this.FreeGreenSquare = new System.Windows.Forms.Panel();
            this.OccuppiedOrangeSquare = new System.Windows.Forms.Panel();
            this.ReservedGraySquare = new System.Windows.Forms.Panel();
            this.OrderedRedSquare = new System.Windows.Forms.Panel();
            this.FreeGreenLabel = new System.Windows.Forms.Label();
            this.OccupiedOrangeLabel = new System.Windows.Forms.Label();
            this.ReservedGrayLabel = new System.Windows.Forms.Label();
            this.OrderedRedLabel = new System.Windows.Forms.Label();
            this.TablesPanel = new System.Windows.Forms.Panel();
            this.LoginPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LogoLoginPanel)).BeginInit();
            this.TableStatusPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LogoTableStatusPanel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LogoTablePanel)).BeginInit();
            this.TablesPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // LoginPanel
            // 
            this.LoginPanel.BackColor = System.Drawing.Color.White;
            this.LoginPanel.Controls.Add(this.ForgotPasswordLabelLoginPanel);
            this.LoginPanel.Controls.Add(this.LoginButtonLoginPanel);
            this.LoginPanel.Controls.Add(this.PasswordLabelLoginPanel);
            this.LoginPanel.Controls.Add(this.UsernameLabelLoginPanel);
            this.LoginPanel.Controls.Add(this.LoginPasswordTextBox);
            this.LoginPanel.Controls.Add(this.LoginEmployeeNumberTextBox);
            this.LoginPanel.Controls.Add(this.LogoLoginPanel);
            this.LoginPanel.Location = new System.Drawing.Point(1, 12);
            this.LoginPanel.Name = "LoginPanel";
            this.LoginPanel.Size = new System.Drawing.Size(642, 699);
            this.LoginPanel.TabIndex = 6;
            // 
            // ForgotPasswordLabelLoginPanel
            // 
            this.ForgotPasswordLabelLoginPanel.AutoSize = true;
            this.ForgotPasswordLabelLoginPanel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point);
            this.ForgotPasswordLabelLoginPanel.Location = new System.Drawing.Point(258, 589);
            this.ForgotPasswordLabelLoginPanel.Name = "ForgotPasswordLabelLoginPanel";
            this.ForgotPasswordLabelLoginPanel.Size = new System.Drawing.Size(127, 21);
            this.ForgotPasswordLabelLoginPanel.TabIndex = 14;
            this.ForgotPasswordLabelLoginPanel.Text = "Forgot password";
            this.ForgotPasswordLabelLoginPanel.Click += new System.EventHandler(this.ForgotPasswordLabelLoginPanel_Click);
            // 
            // LoginButtonLoginPanel
            // 
            this.LoginButtonLoginPanel.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.LoginButtonLoginPanel.Location = new System.Drawing.Point(232, 452);
            this.LoginButtonLoginPanel.Name = "LoginButtonLoginPanel";
            this.LoginButtonLoginPanel.Size = new System.Drawing.Size(160, 62);
            this.LoginButtonLoginPanel.TabIndex = 13;
            this.LoginButtonLoginPanel.Text = "Login";
            this.LoginButtonLoginPanel.UseVisualStyleBackColor = true;
            this.LoginButtonLoginPanel.Click += new System.EventHandler(this.LoginButtonLoginPanel_Click);
            // 
            // PasswordLabelLoginPanel
            // 
            this.PasswordLabelLoginPanel.AutoSize = true;
            this.PasswordLabelLoginPanel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.PasswordLabelLoginPanel.Location = new System.Drawing.Point(167, 355);
            this.PasswordLabelLoginPanel.Name = "PasswordLabelLoginPanel";
            this.PasswordLabelLoginPanel.Size = new System.Drawing.Size(97, 21);
            this.PasswordLabelLoginPanel.TabIndex = 11;
            this.PasswordLabelLoginPanel.Text = "PASSWORD:";
            // 
            // UsernameLabelLoginPanel
            // 
            this.UsernameLabelLoginPanel.AutoSize = true;
            this.UsernameLabelLoginPanel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.UsernameLabelLoginPanel.Location = new System.Drawing.Point(169, 266);
            this.UsernameLabelLoginPanel.Name = "UsernameLabelLoginPanel";
            this.UsernameLabelLoginPanel.Size = new System.Drawing.Size(95, 21);
            this.UsernameLabelLoginPanel.TabIndex = 10;
            this.UsernameLabelLoginPanel.Text = "USERNAME:";
            // 
            // LoginPasswordTextBox
            // 
            this.LoginPasswordTextBox.Location = new System.Drawing.Point(337, 354);
            this.LoginPasswordTextBox.Name = "LoginPasswordTextBox";
            this.LoginPasswordTextBox.PasswordChar = '*';
            this.LoginPasswordTextBox.Size = new System.Drawing.Size(154, 23);
            this.LoginPasswordTextBox.TabIndex = 9;
            // 
            // LoginEmployeeNumberTextBox
            // 
            this.LoginEmployeeNumberTextBox.Location = new System.Drawing.Point(337, 266);
            this.LoginEmployeeNumberTextBox.Name = "LoginEmployeeNumberTextBox";
            this.LoginEmployeeNumberTextBox.Size = new System.Drawing.Size(154, 23);
            this.LoginEmployeeNumberTextBox.TabIndex = 8;
            // 
            // LogoLoginPanel
            // 
            this.LogoLoginPanel.Image = ((System.Drawing.Image)(resources.GetObject("LogoLoginPanel.Image")));
            this.LogoLoginPanel.Location = new System.Drawing.Point(166, 59);
            this.LogoLoginPanel.Name = "LogoLoginPanel";
            this.LogoLoginPanel.Size = new System.Drawing.Size(280, 161);
            this.LogoLoginPanel.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.LogoLoginPanel.TabIndex = 7;
            this.LogoLoginPanel.TabStop = false;
            // 
            // TableStatusPanel
            // 
            this.TableStatusPanel.BackColor = System.Drawing.Color.White;
            this.TableStatusPanel.Controls.Add(this.TableNumberAnswerStatusPanel);
            this.TableStatusPanel.Controls.Add(this.GoToTableButtonTableStatusPanel);
            this.TableStatusPanel.Controls.Add(this.ReservedButtonTableStatusPanel);
            this.TableStatusPanel.Controls.Add(this.OccupiedButtonTableStatusPanel);
            this.TableStatusPanel.Controls.Add(this.FreeButtonTableStatusPanel);
            this.TableStatusPanel.Controls.Add(this.TableNumberLabelStatusPanel);
            this.TableStatusPanel.Controls.Add(this.BackButtonTableStatusPanel);
            this.TableStatusPanel.Controls.Add(this.LogoTableStatusPanel);
            this.TableStatusPanel.Location = new System.Drawing.Point(1, 3);
            this.TableStatusPanel.Name = "TableStatusPanel";
            this.TableStatusPanel.Size = new System.Drawing.Size(639, 693);
            this.TableStatusPanel.TabIndex = 8;
            // 
            // TableNumberAnswerStatusPanel
            // 
            this.TableNumberAnswerStatusPanel.AutoSize = true;
            this.TableNumberAnswerStatusPanel.Font = new System.Drawing.Font("Segoe UI", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.TableNumberAnswerStatusPanel.Location = new System.Drawing.Point(337, 221);
            this.TableNumberAnswerStatusPanel.Name = "TableNumberAnswerStatusPanel";
            this.TableNumberAnswerStatusPanel.Size = new System.Drawing.Size(0, 54);
            this.TableNumberAnswerStatusPanel.TabIndex = 30;
            // 
            // GoToTableButtonTableStatusPanel
            // 
            this.GoToTableButtonTableStatusPanel.BackColor = System.Drawing.Color.Violet;
            this.GoToTableButtonTableStatusPanel.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.GoToTableButtonTableStatusPanel.Location = new System.Drawing.Point(183, 503);
            this.GoToTableButtonTableStatusPanel.Name = "GoToTableButtonTableStatusPanel";
            this.GoToTableButtonTableStatusPanel.Size = new System.Drawing.Size(234, 42);
            this.GoToTableButtonTableStatusPanel.TabIndex = 29;
            this.GoToTableButtonTableStatusPanel.Text = "Go to table";
            this.GoToTableButtonTableStatusPanel.UseVisualStyleBackColor = false;
            this.GoToTableButtonTableStatusPanel.Click += new System.EventHandler(this.GoToTableButtonTableStatusPanel_Click);
            // 
            // ReservedButtonTableStatusPanel
            // 
            this.ReservedButtonTableStatusPanel.BackColor = System.Drawing.Color.Silver;
            this.ReservedButtonTableStatusPanel.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.ReservedButtonTableStatusPanel.Location = new System.Drawing.Point(431, 364);
            this.ReservedButtonTableStatusPanel.Name = "ReservedButtonTableStatusPanel";
            this.ReservedButtonTableStatusPanel.Size = new System.Drawing.Size(127, 48);
            this.ReservedButtonTableStatusPanel.TabIndex = 28;
            this.ReservedButtonTableStatusPanel.Text = "RESERVED";
            this.ReservedButtonTableStatusPanel.UseVisualStyleBackColor = false;
            this.ReservedButtonTableStatusPanel.Click += new System.EventHandler(this.ReservedButtonTableStatusPanel_Click);
            // 
            // OccupiedButtonTableStatusPanel
            // 
            this.OccupiedButtonTableStatusPanel.BackColor = System.Drawing.Color.Orange;
            this.OccupiedButtonTableStatusPanel.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.OccupiedButtonTableStatusPanel.Location = new System.Drawing.Point(250, 363);
            this.OccupiedButtonTableStatusPanel.Name = "OccupiedButtonTableStatusPanel";
            this.OccupiedButtonTableStatusPanel.Size = new System.Drawing.Size(127, 48);
            this.OccupiedButtonTableStatusPanel.TabIndex = 27;
            this.OccupiedButtonTableStatusPanel.Text = "OCCUPIED";
            this.OccupiedButtonTableStatusPanel.UseVisualStyleBackColor = false;
            this.OccupiedButtonTableStatusPanel.Click += new System.EventHandler(this.OccupiedButtonTableStatusPanel_Click);
            // 
            // FreeButtonTableStatusPanel
            // 
            this.FreeButtonTableStatusPanel.BackColor = System.Drawing.Color.LawnGreen;
            this.FreeButtonTableStatusPanel.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.FreeButtonTableStatusPanel.Location = new System.Drawing.Point(67, 364);
            this.FreeButtonTableStatusPanel.Name = "FreeButtonTableStatusPanel";
            this.FreeButtonTableStatusPanel.Size = new System.Drawing.Size(127, 48);
            this.FreeButtonTableStatusPanel.TabIndex = 26;
            this.FreeButtonTableStatusPanel.Text = "FREE";
            this.FreeButtonTableStatusPanel.UseVisualStyleBackColor = false;
            this.FreeButtonTableStatusPanel.Click += new System.EventHandler(this.FreeButtonTableStatusPanel_Click);
            // 
            // TableNumberLabelStatusPanel
            // 
            this.TableNumberLabelStatusPanel.AutoSize = true;
            this.TableNumberLabelStatusPanel.Font = new System.Drawing.Font("Segoe UI", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.TableNumberLabelStatusPanel.Location = new System.Drawing.Point(199, 221);
            this.TableNumberLabelStatusPanel.Name = "TableNumberLabelStatusPanel";
            this.TableNumberLabelStatusPanel.Size = new System.Drawing.Size(149, 54);
            this.TableNumberLabelStatusPanel.TabIndex = 25;
            this.TableNumberLabelStatusPanel.Text = "TABLE ";
            // 
            // BackButtonTableStatusPanel
            // 
            this.BackButtonTableStatusPanel.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.BackButtonTableStatusPanel.Location = new System.Drawing.Point(11, 652);
            this.BackButtonTableStatusPanel.Name = "BackButtonTableStatusPanel";
            this.BackButtonTableStatusPanel.Size = new System.Drawing.Size(119, 33);
            this.BackButtonTableStatusPanel.TabIndex = 24;
            this.BackButtonTableStatusPanel.Text = "Back";
            this.BackButtonTableStatusPanel.UseVisualStyleBackColor = true;
            this.BackButtonTableStatusPanel.Click += new System.EventHandler(this.BackButtonTableStatusPanel_Click);
            // 
            // LogoTableStatusPanel
            // 
            this.LogoTableStatusPanel.Image = ((System.Drawing.Image)(resources.GetObject("LogoTableStatusPanel.Image")));
            this.LogoTableStatusPanel.Location = new System.Drawing.Point(11, 12);
            this.LogoTableStatusPanel.Name = "LogoTableStatusPanel";
            this.LogoTableStatusPanel.Size = new System.Drawing.Size(197, 96);
            this.LogoTableStatusPanel.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.LogoTableStatusPanel.TabIndex = 7;
            this.LogoTableStatusPanel.TabStop = false;
            // 
            // TableButton1
            // 
            this.TableButton1.BackColor = System.Drawing.Color.LawnGreen;
            this.TableButton1.Font = new System.Drawing.Font("Segoe UI", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TableButton1.Location = new System.Drawing.Point(142, 130);
            this.TableButton1.Name = "TableButton1";
            this.TableButton1.Size = new System.Drawing.Size(87, 70);
            this.TableButton1.TabIndex = 0;
            this.TableButton1.Text = "1";
            this.TableButton1.UseVisualStyleBackColor = false;
            this.TableButton1.Click += new System.EventHandler(this.TableButton1_Click);
            // 
            // TableButton2
            // 
            this.TableButton2.BackColor = System.Drawing.Color.LawnGreen;
            this.TableButton2.Font = new System.Drawing.Font("Segoe UI", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TableButton2.Location = new System.Drawing.Point(363, 130);
            this.TableButton2.Name = "TableButton2";
            this.TableButton2.Size = new System.Drawing.Size(87, 70);
            this.TableButton2.TabIndex = 1;
            this.TableButton2.Text = "2";
            this.TableButton2.UseVisualStyleBackColor = false;
            this.TableButton2.Click += new System.EventHandler(this.TableButton2_Click);
            // 
            // TableButton3
            // 
            this.TableButton3.BackColor = System.Drawing.Color.LawnGreen;
            this.TableButton3.Font = new System.Drawing.Font("Segoe UI", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TableButton3.Location = new System.Drawing.Point(142, 220);
            this.TableButton3.Name = "TableButton3";
            this.TableButton3.Size = new System.Drawing.Size(87, 70);
            this.TableButton3.TabIndex = 2;
            this.TableButton3.Text = "3";
            this.TableButton3.UseVisualStyleBackColor = false;
            this.TableButton3.Click += new System.EventHandler(this.TableButton3_Click);
            // 
            // TableButton4
            // 
            this.TableButton4.BackColor = System.Drawing.Color.LawnGreen;
            this.TableButton4.Font = new System.Drawing.Font("Segoe UI", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TableButton4.Location = new System.Drawing.Point(363, 220);
            this.TableButton4.Name = "TableButton4";
            this.TableButton4.Size = new System.Drawing.Size(87, 70);
            this.TableButton4.TabIndex = 3;
            this.TableButton4.Text = "4";
            this.TableButton4.UseVisualStyleBackColor = false;
            this.TableButton4.Click += new System.EventHandler(this.TableButton4_Click);
            // 
            // TableButton5
            // 
            this.TableButton5.BackColor = System.Drawing.Color.LawnGreen;
            this.TableButton5.Font = new System.Drawing.Font("Segoe UI", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TableButton5.Location = new System.Drawing.Point(142, 306);
            this.TableButton5.Name = "TableButton5";
            this.TableButton5.Size = new System.Drawing.Size(87, 70);
            this.TableButton5.TabIndex = 4;
            this.TableButton5.Text = "5";
            this.TableButton5.UseVisualStyleBackColor = false;
            this.TableButton5.Click += new System.EventHandler(this.TableButton5_Click);
            // 
            // TableButton6
            // 
            this.TableButton6.BackColor = System.Drawing.Color.LawnGreen;
            this.TableButton6.Font = new System.Drawing.Font("Segoe UI", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TableButton6.Location = new System.Drawing.Point(363, 306);
            this.TableButton6.Name = "TableButton6";
            this.TableButton6.Size = new System.Drawing.Size(87, 70);
            this.TableButton6.TabIndex = 5;
            this.TableButton6.Text = "6";
            this.TableButton6.UseVisualStyleBackColor = false;
            this.TableButton6.Click += new System.EventHandler(this.TableButton6_Click);
            // 
            // TableButton7
            // 
            this.TableButton7.BackColor = System.Drawing.Color.LawnGreen;
            this.TableButton7.Font = new System.Drawing.Font("Segoe UI", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TableButton7.Location = new System.Drawing.Point(142, 391);
            this.TableButton7.Name = "TableButton7";
            this.TableButton7.Size = new System.Drawing.Size(87, 70);
            this.TableButton7.TabIndex = 6;
            this.TableButton7.Text = "7";
            this.TableButton7.UseVisualStyleBackColor = false;
            this.TableButton7.Click += new System.EventHandler(this.TableButton7_Click);
            // 
            // TableButton8
            // 
            this.TableButton8.BackColor = System.Drawing.Color.LawnGreen;
            this.TableButton8.Font = new System.Drawing.Font("Segoe UI", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TableButton8.Location = new System.Drawing.Point(363, 391);
            this.TableButton8.Name = "TableButton8";
            this.TableButton8.Size = new System.Drawing.Size(87, 70);
            this.TableButton8.TabIndex = 7;
            this.TableButton8.Text = "8";
            this.TableButton8.UseVisualStyleBackColor = false;
            this.TableButton8.Click += new System.EventHandler(this.TableButton8_Click);
            // 
            // TableButton9
            // 
            this.TableButton9.BackColor = System.Drawing.Color.LawnGreen;
            this.TableButton9.Font = new System.Drawing.Font("Segoe UI", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TableButton9.Location = new System.Drawing.Point(142, 479);
            this.TableButton9.Name = "TableButton9";
            this.TableButton9.Size = new System.Drawing.Size(87, 70);
            this.TableButton9.TabIndex = 8;
            this.TableButton9.Text = "9";
            this.TableButton9.UseVisualStyleBackColor = false;
            this.TableButton9.Click += new System.EventHandler(this.TableButton9_Click);
            // 
            // TableButton10
            // 
            this.TableButton10.BackColor = System.Drawing.Color.LawnGreen;
            this.TableButton10.Font = new System.Drawing.Font("Segoe UI", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TableButton10.Location = new System.Drawing.Point(363, 479);
            this.TableButton10.Name = "TableButton10";
            this.TableButton10.Size = new System.Drawing.Size(87, 70);
            this.TableButton10.TabIndex = 9;
            this.TableButton10.Text = "10";
            this.TableButton10.UseVisualStyleBackColor = false;
            this.TableButton10.Click += new System.EventHandler(this.TableButton10_Click);
            // 
            // LogoTablePanel
            // 
            this.LogoTablePanel.Image = ((System.Drawing.Image)(resources.GetObject("LogoTablePanel.Image")));
            this.LogoTablePanel.Location = new System.Drawing.Point(21, 13);
            this.LogoTablePanel.Name = "LogoTablePanel";
            this.LogoTablePanel.Size = new System.Drawing.Size(192, 97);
            this.LogoTablePanel.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.LogoTablePanel.TabIndex = 11;
            this.LogoTablePanel.TabStop = false;
            // 
            // BackButtonTablePanel
            // 
            this.BackButtonTablePanel.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.BackButtonTablePanel.Location = new System.Drawing.Point(514, 648);
            this.BackButtonTablePanel.Name = "BackButtonTablePanel";
            this.BackButtonTablePanel.Size = new System.Drawing.Size(119, 33);
            this.BackButtonTablePanel.TabIndex = 23;
            this.BackButtonTablePanel.Text = "Log Out";
            this.BackButtonTablePanel.UseVisualStyleBackColor = true;
            this.BackButtonTablePanel.Click += new System.EventHandler(this.BackButtonTablePanel_Click);
            // 
            // EmployeeNameTablesPanel
            // 
            this.EmployeeNameTablesPanel.AutoSize = true;
            this.EmployeeNameTablesPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.EmployeeNameTablesPanel.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.EmployeeNameTablesPanel.Location = new System.Drawing.Point(453, 39);
            this.EmployeeNameTablesPanel.Name = "EmployeeNameTablesPanel";
            this.EmployeeNameTablesPanel.Size = new System.Drawing.Size(151, 30);
            this.EmployeeNameTablesPanel.TabIndex = 24;
            this.EmployeeNameTablesPanel.Text = "MEDEWERKER";
            // 
            // FreeGreenSquare
            // 
            this.FreeGreenSquare.BackColor = System.Drawing.Color.LawnGreen;
            this.FreeGreenSquare.Location = new System.Drawing.Point(115, 582);
            this.FreeGreenSquare.Name = "FreeGreenSquare";
            this.FreeGreenSquare.Size = new System.Drawing.Size(27, 28);
            this.FreeGreenSquare.TabIndex = 25;
            // 
            // OccuppiedOrangeSquare
            // 
            this.OccuppiedOrangeSquare.BackColor = System.Drawing.Color.Orange;
            this.OccuppiedOrangeSquare.Location = new System.Drawing.Point(214, 582);
            this.OccuppiedOrangeSquare.Name = "OccuppiedOrangeSquare";
            this.OccuppiedOrangeSquare.Size = new System.Drawing.Size(27, 28);
            this.OccuppiedOrangeSquare.TabIndex = 26;
            // 
            // ReservedGraySquare
            // 
            this.ReservedGraySquare.BackColor = System.Drawing.Color.Silver;
            this.ReservedGraySquare.Location = new System.Drawing.Point(337, 582);
            this.ReservedGraySquare.Name = "ReservedGraySquare";
            this.ReservedGraySquare.Size = new System.Drawing.Size(27, 28);
            this.ReservedGraySquare.TabIndex = 27;
            // 
            // OrderedRedSquare
            // 
            this.OrderedRedSquare.BackColor = System.Drawing.Color.Red;
            this.OrderedRedSquare.Location = new System.Drawing.Point(447, 582);
            this.OrderedRedSquare.Name = "OrderedRedSquare";
            this.OrderedRedSquare.Size = new System.Drawing.Size(27, 28);
            this.OrderedRedSquare.TabIndex = 27;
            // 
            // FreeGreenLabel
            // 
            this.FreeGreenLabel.AutoSize = true;
            this.FreeGreenLabel.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.FreeGreenLabel.Location = new System.Drawing.Point(115, 630);
            this.FreeGreenLabel.Name = "FreeGreenLabel";
            this.FreeGreenLabel.Size = new System.Drawing.Size(33, 15);
            this.FreeGreenLabel.TabIndex = 28;
            this.FreeGreenLabel.Text = "FREE";
            // 
            // OccupiedOrangeLabel
            // 
            this.OccupiedOrangeLabel.AutoSize = true;
            this.OccupiedOrangeLabel.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.OccupiedOrangeLabel.Location = new System.Drawing.Point(199, 630);
            this.OccupiedOrangeLabel.Name = "OccupiedOrangeLabel";
            this.OccupiedOrangeLabel.Size = new System.Drawing.Size(65, 15);
            this.OccupiedOrangeLabel.TabIndex = 29;
            this.OccupiedOrangeLabel.Text = "OCCUPIED";
            // 
            // ReservedGrayLabel
            // 
            this.ReservedGrayLabel.AutoSize = true;
            this.ReservedGrayLabel.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.ReservedGrayLabel.Location = new System.Drawing.Point(320, 630);
            this.ReservedGrayLabel.Name = "ReservedGrayLabel";
            this.ReservedGrayLabel.Size = new System.Drawing.Size(65, 15);
            this.ReservedGrayLabel.TabIndex = 30;
            this.ReservedGrayLabel.Text = "RESERVED";
            // 
            // OrderedRedLabel
            // 
            this.OrderedRedLabel.AutoSize = true;
            this.OrderedRedLabel.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.OrderedRedLabel.Location = new System.Drawing.Point(431, 630);
            this.OrderedRedLabel.Name = "OrderedRedLabel";
            this.OrderedRedLabel.Size = new System.Drawing.Size(62, 15);
            this.OrderedRedLabel.TabIndex = 31;
            this.OrderedRedLabel.Text = "ORDERED";
            // 
            // TablesPanel
            // 
            this.TablesPanel.BackColor = System.Drawing.Color.White;
            this.TablesPanel.Controls.Add(this.OrderedRedLabel);
            this.TablesPanel.Controls.Add(this.ReservedGrayLabel);
            this.TablesPanel.Controls.Add(this.OccupiedOrangeLabel);
            this.TablesPanel.Controls.Add(this.FreeGreenLabel);
            this.TablesPanel.Controls.Add(this.OrderedRedSquare);
            this.TablesPanel.Controls.Add(this.ReservedGraySquare);
            this.TablesPanel.Controls.Add(this.OccuppiedOrangeSquare);
            this.TablesPanel.Controls.Add(this.FreeGreenSquare);
            this.TablesPanel.Controls.Add(this.EmployeeNameTablesPanel);
            this.TablesPanel.Controls.Add(this.BackButtonTablePanel);
            this.TablesPanel.Controls.Add(this.LogoTablePanel);
            this.TablesPanel.Controls.Add(this.TableButton10);
            this.TablesPanel.Controls.Add(this.TableButton9);
            this.TablesPanel.Controls.Add(this.TableButton8);
            this.TablesPanel.Controls.Add(this.TableButton7);
            this.TablesPanel.Controls.Add(this.TableButton6);
            this.TablesPanel.Controls.Add(this.TableButton5);
            this.TablesPanel.Controls.Add(this.TableButton4);
            this.TablesPanel.Controls.Add(this.TableButton3);
            this.TablesPanel.Controls.Add(this.TableButton2);
            this.TablesPanel.Controls.Add(this.TableButton1);
            this.TablesPanel.Location = new System.Drawing.Point(1, 12);
            this.TablesPanel.Name = "TablesPanel";
            this.TablesPanel.Size = new System.Drawing.Size(639, 696);
            this.TablesPanel.TabIndex = 6;
            // 
            // ProjectChapeau
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(643, 700);
            this.Controls.Add(this.LoginPanel);
            this.Controls.Add(this.TablesPanel);
            this.Controls.Add(this.TableStatusPanel);
            this.Name = "ProjectChapeau";
            this.Text = "ProjectChapeau";
            this.Load += new System.EventHandler(this.ProjectChapeau_Load);
            this.LoginPanel.ResumeLayout(false);
            this.LoginPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LogoLoginPanel)).EndInit();
            this.TableStatusPanel.ResumeLayout(false);
            this.TableStatusPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LogoTableStatusPanel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LogoTablePanel)).EndInit();
            this.TablesPanel.ResumeLayout(false);
            this.TablesPanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private Panel LoginPanel;
        private PictureBox LogoLoginPanel;
        private Button LoginButtonLoginPanel;
        private Label PasswordLabelLoginPanel;
        private Label UsernameLabelLoginPanel;
        private TextBox LoginPasswordTextBox;
        private TextBox LoginEmployeeNumberTextBox;
        private Panel TableStatusPanel;
        private PictureBox LogoTableStatusPanel;
        private Button BackButtonTableStatusPanel;
        private Label ForgotPasswordLabelLoginPanel;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private Label TableNumberLabelStatusPanel;
        private Button GoToTableButtonTableStatusPanel;
        private Button ReservedButtonTableStatusPanel;
        private Button OccupiedButtonTableStatusPanel;
        private Button FreeButtonTableStatusPanel;
        private Button TableButton1;
        private Button TableButton2;
        private Button TableButton3;
        private Button TableButton4;
        private Button TableButton5;
        private Button TableButton6;
        private Button TableButton7;
        private Button TableButton8;
        private Button TableButton9;
        private Button TableButton10;
        private PictureBox LogoTablePanel;
        private Button BackButtonTablePanel;
        private Label EmployeeNameTablesPanel;
        private Panel FreeGreenSquare;
        private Panel OccuppiedOrangeSquare;
        private Panel ReservedGraySquare;
        private Panel OrderedRedSquare;
        private Label FreeGreenLabel;
        private Label OccupiedOrangeLabel;
        private Label ReservedGrayLabel;
        private Label OrderedRedLabel;
        private Panel TablesPanel;
        private Label TableNumberAnswerStatusPanel;
    }
}