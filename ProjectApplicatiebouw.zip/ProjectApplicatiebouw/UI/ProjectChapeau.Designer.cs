﻿namespace UI
{
    partial class ProjectChapeau
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.AddItem = new System.Windows.Forms.Button();
            this.TafelNummer = new System.Windows.Forms.TextBox();
            this.KlantNummer = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // AddItem
            // 
            this.AddItem.Location = new System.Drawing.Point(132, 186);
            this.AddItem.Name = "AddItem";
            this.AddItem.Size = new System.Drawing.Size(75, 23);
            this.AddItem.TabIndex = 0;
            this.AddItem.Text = "Add Bestelling";
            this.AddItem.UseVisualStyleBackColor = true;
            this.AddItem.Click += new System.EventHandler(this.AddItem_Click);
            // 
            // TafelNummer
            // 
            this.TafelNummer.Location = new System.Drawing.Point(132, 80);
            this.TafelNummer.Name = "TafelNummer";
            this.TafelNummer.Size = new System.Drawing.Size(100, 23);
            this.TafelNummer.TabIndex = 1;
            // 
            // KlantNummer
            // 
            this.KlantNummer.Location = new System.Drawing.Point(132, 125);
            this.KlantNummer.Name = "KlantNummer";
            this.KlantNummer.Size = new System.Drawing.Size(100, 23);
            this.KlantNummer.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(115, 334);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 15);
            this.label1.TabIndex = 3;
            // 
            // ProjectChapeau
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.KlantNummer);
            this.Controls.Add(this.TafelNummer);
            this.Controls.Add(this.AddItem);
            this.Name = "ProjectChapeau";
            this.Text = "ProjectChapeau";
            this.Load += new System.EventHandler(this.ProjectChapeau_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button AddItem;
        private TextBox TafelNummer;
        private TextBox KlantNummer;
        private Label label1;
    }
}