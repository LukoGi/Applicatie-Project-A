﻿namespace UI
{
    partial class ProjectChapeau
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ProjectChapeau));
            this.HomePanel = new System.Windows.Forms.Panel();
            this.LogoHomePanel = new System.Windows.Forms.PictureBox();
            this.TitleLabelHomePanel = new System.Windows.Forms.Label();
            this.LoginButtonHomePanel = new System.Windows.Forms.Button();
            this.ManagerHomePanel = new System.Windows.Forms.Panel();
            this.AdjustMenuLogoManagerHomePanel = new System.Windows.Forms.PictureBox();
            this.AddEmployeeLogoManagerHomePanel = new System.Windows.Forms.PictureBox();
            this.SuppliesLogoManagerHomePanel = new System.Windows.Forms.PictureBox();
            this.LogoutButtonManagerHomePanel = new System.Windows.Forms.Button();
            this.PictureOfManagerHomePanel = new System.Windows.Forms.PictureBox();
            this.LogoManagerHomePanel = new System.Windows.Forms.PictureBox();
            this.TitleManagerHomePanel = new System.Windows.Forms.Label();
            this.LoginPanel = new System.Windows.Forms.Panel();
            this.ContinueButtonLoginPanel = new System.Windows.Forms.Button();
            this.CancelButtonLoginPanel = new System.Windows.Forms.Button();
            this.LoginPasswordLabel = new System.Windows.Forms.Label();
            this.LoginEmployeeNumberLabel = new System.Windows.Forms.Label();
            this.LoginPasswordTextBox = new System.Windows.Forms.TextBox();
            this.LoginEmployeeNumberTextBox = new System.Windows.Forms.TextBox();
            this.LogoLoginPanel = new System.Windows.Forms.PictureBox();
            this.TitleLabelLoginPanel = new System.Windows.Forms.Label();
            this.WaiterHomePanel = new System.Windows.Forms.Panel();
            this.TablesOverviewLogoWaiterPanel = new System.Windows.Forms.PictureBox();
            this.PaymentLogoWaiterPanel = new System.Windows.Forms.PictureBox();
            this.OrderLogoWaiterPanel = new System.Windows.Forms.PictureBox();
            this.NotifyLogoWaiterPanel = new System.Windows.Forms.PictureBox();
            this.LogOutButtonWaiterHomePanel = new System.Windows.Forms.Button();
            this.PictureOfWaterHomePanel = new System.Windows.Forms.PictureBox();
            this.LogoWaiterHomePanel = new System.Windows.Forms.PictureBox();
            this.TitleWaiterHomePanel = new System.Windows.Forms.Label();
            this.TablesOverviewPanel = new System.Windows.Forms.Panel();
            this.BackButtonTablePanel = new System.Windows.Forms.Button();
            this.ModifyButton10 = new System.Windows.Forms.Button();
            this.ModifyButton9 = new System.Windows.Forms.Button();
            this.ModifyButton8 = new System.Windows.Forms.Button();
            this.ModifyButton7 = new System.Windows.Forms.Button();
            this.ModifyButton6 = new System.Windows.Forms.Button();
            this.ModifyButton5 = new System.Windows.Forms.Button();
            this.ModifyButton4 = new System.Windows.Forms.Button();
            this.ModifyButton3 = new System.Windows.Forms.Button();
            this.ModifyButton2 = new System.Windows.Forms.Button();
            this.ModifyButton1 = new System.Windows.Forms.Button();
            this.InstructionLabelTablePanel = new System.Windows.Forms.Label();
            this.LogoTablePanel = new System.Windows.Forms.PictureBox();
            this.TitleTablePanel = new System.Windows.Forms.Label();
            this.TableButton10 = new System.Windows.Forms.Button();
            this.TableButton9 = new System.Windows.Forms.Button();
            this.TableButton8 = new System.Windows.Forms.Button();
            this.TableButton7 = new System.Windows.Forms.Button();
            this.TableButton6 = new System.Windows.Forms.Button();
            this.TableButton5 = new System.Windows.Forms.Button();
            this.TableButton4 = new System.Windows.Forms.Button();
            this.TableButton3 = new System.Windows.Forms.Button();
            this.TableButton2 = new System.Windows.Forms.Button();
            this.TableButton1 = new System.Windows.Forms.Button();
            this.HomePanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LogoHomePanel)).BeginInit();
            this.ManagerHomePanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AdjustMenuLogoManagerHomePanel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.AddEmployeeLogoManagerHomePanel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SuppliesLogoManagerHomePanel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureOfManagerHomePanel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LogoManagerHomePanel)).BeginInit();
            this.LoginPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LogoLoginPanel)).BeginInit();
            this.WaiterHomePanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TablesOverviewLogoWaiterPanel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PaymentLogoWaiterPanel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.OrderLogoWaiterPanel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NotifyLogoWaiterPanel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureOfWaterHomePanel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LogoWaiterHomePanel)).BeginInit();
            this.TablesOverviewPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LogoTablePanel)).BeginInit();
            this.SuspendLayout();
            // 
            // HomePanel
            // 
            this.HomePanel.Controls.Add(this.LogoHomePanel);
            this.HomePanel.Controls.Add(this.TitleLabelHomePanel);
            this.HomePanel.Controls.Add(this.LoginButtonHomePanel);
            this.HomePanel.Location = new System.Drawing.Point(1, 9);
            this.HomePanel.Name = "HomePanel";
            this.HomePanel.Size = new System.Drawing.Size(645, 699);
            this.HomePanel.TabIndex = 4;
            // 
            // LogoHomePanel
            // 
            this.LogoHomePanel.Image = ((System.Drawing.Image)(resources.GetObject("LogoHomePanel.Image")));
            this.LogoHomePanel.Location = new System.Drawing.Point(418, 10);
            this.LogoHomePanel.Name = "LogoHomePanel";
            this.LogoHomePanel.Size = new System.Drawing.Size(197, 96);
            this.LogoHomePanel.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.LogoHomePanel.TabIndex = 5;
            this.LogoHomePanel.TabStop = false;
            // 
            // TitleLabelHomePanel
            // 
            this.TitleLabelHomePanel.AutoSize = true;
            this.TitleLabelHomePanel.Font = new System.Drawing.Font("Segoe UI", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.TitleLabelHomePanel.Location = new System.Drawing.Point(17, 22);
            this.TitleLabelHomePanel.Name = "TitleLabelHomePanel";
            this.TitleLabelHomePanel.Size = new System.Drawing.Size(383, 47);
            this.TitleLabelHomePanel.TabIndex = 4;
            this.TitleLabelHomePanel.Text = "Restaurant Champeau";
            // 
            // LoginButtonHomePanel
            // 
            this.LoginButtonHomePanel.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.LoginButtonHomePanel.Location = new System.Drawing.Point(208, 257);
            this.LoginButtonHomePanel.Name = "LoginButtonHomePanel";
            this.LoginButtonHomePanel.Size = new System.Drawing.Size(214, 78);
            this.LoginButtonHomePanel.TabIndex = 0;
            this.LoginButtonHomePanel.Text = "Login";
            this.LoginButtonHomePanel.UseVisualStyleBackColor = true;
            this.LoginButtonHomePanel.Click += new System.EventHandler(this.LoginButtonHomePanel_Click);
            // 
            // ManagerHomePanel
            // 
            this.ManagerHomePanel.Controls.Add(this.AdjustMenuLogoManagerHomePanel);
            this.ManagerHomePanel.Controls.Add(this.AddEmployeeLogoManagerHomePanel);
            this.ManagerHomePanel.Controls.Add(this.SuppliesLogoManagerHomePanel);
            this.ManagerHomePanel.Controls.Add(this.LogoutButtonManagerHomePanel);
            this.ManagerHomePanel.Controls.Add(this.PictureOfManagerHomePanel);
            this.ManagerHomePanel.Controls.Add(this.LogoManagerHomePanel);
            this.ManagerHomePanel.Controls.Add(this.TitleManagerHomePanel);
            this.ManagerHomePanel.Location = new System.Drawing.Point(4, 3);
            this.ManagerHomePanel.Name = "ManagerHomePanel";
            this.ManagerHomePanel.Size = new System.Drawing.Size(639, 696);
            this.ManagerHomePanel.TabIndex = 7;
            // 
            // AdjustMenuLogoManagerHomePanel
            // 
            this.AdjustMenuLogoManagerHomePanel.Image = ((System.Drawing.Image)(resources.GetObject("AdjustMenuLogoManagerHomePanel.Image")));
            this.AdjustMenuLogoManagerHomePanel.Location = new System.Drawing.Point(464, 195);
            this.AdjustMenuLogoManagerHomePanel.Name = "AdjustMenuLogoManagerHomePanel";
            this.AdjustMenuLogoManagerHomePanel.Size = new System.Drawing.Size(132, 172);
            this.AdjustMenuLogoManagerHomePanel.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.AdjustMenuLogoManagerHomePanel.TabIndex = 14;
            this.AdjustMenuLogoManagerHomePanel.TabStop = false;
            // 
            // AddEmployeeLogoManagerHomePanel
            // 
            this.AddEmployeeLogoManagerHomePanel.Image = ((System.Drawing.Image)(resources.GetObject("AddEmployeeLogoManagerHomePanel.Image")));
            this.AddEmployeeLogoManagerHomePanel.Location = new System.Drawing.Point(267, 195);
            this.AddEmployeeLogoManagerHomePanel.Name = "AddEmployeeLogoManagerHomePanel";
            this.AddEmployeeLogoManagerHomePanel.Size = new System.Drawing.Size(133, 172);
            this.AddEmployeeLogoManagerHomePanel.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.AddEmployeeLogoManagerHomePanel.TabIndex = 13;
            this.AddEmployeeLogoManagerHomePanel.TabStop = false;
            // 
            // SuppliesLogoManagerHomePanel
            // 
            this.SuppliesLogoManagerHomePanel.Image = ((System.Drawing.Image)(resources.GetObject("SuppliesLogoManagerHomePanel.Image")));
            this.SuppliesLogoManagerHomePanel.Location = new System.Drawing.Point(53, 195);
            this.SuppliesLogoManagerHomePanel.Name = "SuppliesLogoManagerHomePanel";
            this.SuppliesLogoManagerHomePanel.Size = new System.Drawing.Size(138, 172);
            this.SuppliesLogoManagerHomePanel.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.SuppliesLogoManagerHomePanel.TabIndex = 12;
            this.SuppliesLogoManagerHomePanel.TabStop = false;
            // 
            // LogoutButtonManagerHomePanel
            // 
            this.LogoutButtonManagerHomePanel.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.LogoutButtonManagerHomePanel.Location = new System.Drawing.Point(477, 610);
            this.LogoutButtonManagerHomePanel.Name = "LogoutButtonManagerHomePanel";
            this.LogoutButtonManagerHomePanel.Size = new System.Drawing.Size(119, 41);
            this.LogoutButtonManagerHomePanel.TabIndex = 11;
            this.LogoutButtonManagerHomePanel.Text = "Log out";
            this.LogoutButtonManagerHomePanel.UseVisualStyleBackColor = true;
            this.LogoutButtonManagerHomePanel.Click += new System.EventHandler(this.LogoutButtonManagerHomePanel_Click);
            // 
            // PictureOfManagerHomePanel
            // 
            this.PictureOfManagerHomePanel.Image = global::UI.Properties.Resources.ManagerFoto1;
            this.PictureOfManagerHomePanel.Location = new System.Drawing.Point(487, 19);
            this.PictureOfManagerHomePanel.Name = "PictureOfManagerHomePanel";
            this.PictureOfManagerHomePanel.Size = new System.Drawing.Size(128, 135);
            this.PictureOfManagerHomePanel.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PictureOfManagerHomePanel.TabIndex = 10;
            this.PictureOfManagerHomePanel.TabStop = false;
            // 
            // LogoManagerHomePanel
            // 
            this.LogoManagerHomePanel.Image = ((System.Drawing.Image)(resources.GetObject("LogoManagerHomePanel.Image")));
            this.LogoManagerHomePanel.Location = new System.Drawing.Point(250, 19);
            this.LogoManagerHomePanel.Name = "LogoManagerHomePanel";
            this.LogoManagerHomePanel.Size = new System.Drawing.Size(197, 96);
            this.LogoManagerHomePanel.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.LogoManagerHomePanel.TabIndex = 9;
            this.LogoManagerHomePanel.TabStop = false;
            // 
            // TitleManagerHomePanel
            // 
            this.TitleManagerHomePanel.AutoSize = true;
            this.TitleManagerHomePanel.Font = new System.Drawing.Font("Segoe UI", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.TitleManagerHomePanel.Location = new System.Drawing.Point(21, 21);
            this.TitleManagerHomePanel.Name = "TitleManagerHomePanel";
            this.TitleManagerHomePanel.Size = new System.Drawing.Size(208, 94);
            this.TitleManagerHomePanel.TabIndex = 8;
            this.TitleManagerHomePanel.Text = "Restaurant \r\nChampeau";
            // 
            // LoginPanel
            // 
            this.LoginPanel.Controls.Add(this.ContinueButtonLoginPanel);
            this.LoginPanel.Controls.Add(this.CancelButtonLoginPanel);
            this.LoginPanel.Controls.Add(this.LoginPasswordLabel);
            this.LoginPanel.Controls.Add(this.LoginEmployeeNumberLabel);
            this.LoginPanel.Controls.Add(this.LoginPasswordTextBox);
            this.LoginPanel.Controls.Add(this.LoginEmployeeNumberTextBox);
            this.LoginPanel.Controls.Add(this.LogoLoginPanel);
            this.LoginPanel.Controls.Add(this.TitleLabelLoginPanel);
            this.LoginPanel.Location = new System.Drawing.Point(1, 12);
            this.LoginPanel.Name = "LoginPanel";
            this.LoginPanel.Size = new System.Drawing.Size(642, 699);
            this.LoginPanel.TabIndex = 6;
            // 
            // ContinueButtonLoginPanel
            // 
            this.ContinueButtonLoginPanel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ContinueButtonLoginPanel.Location = new System.Drawing.Point(357, 445);
            this.ContinueButtonLoginPanel.Name = "ContinueButtonLoginPanel";
            this.ContinueButtonLoginPanel.Size = new System.Drawing.Size(116, 36);
            this.ContinueButtonLoginPanel.TabIndex = 13;
            this.ContinueButtonLoginPanel.Text = "Continue";
            this.ContinueButtonLoginPanel.UseVisualStyleBackColor = true;
            this.ContinueButtonLoginPanel.Click += new System.EventHandler(this.ContinueButtonLoginPanel_Click);
            // 
            // CancelButtonLoginPanel
            // 
            this.CancelButtonLoginPanel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.CancelButtonLoginPanel.Location = new System.Drawing.Point(115, 445);
            this.CancelButtonLoginPanel.Name = "CancelButtonLoginPanel";
            this.CancelButtonLoginPanel.Size = new System.Drawing.Size(114, 36);
            this.CancelButtonLoginPanel.TabIndex = 12;
            this.CancelButtonLoginPanel.Text = "Cancel";
            this.CancelButtonLoginPanel.UseVisualStyleBackColor = true;
            this.CancelButtonLoginPanel.Click += new System.EventHandler(this.CancelButtonLoginPanel_Click);
            // 
            // LoginPasswordLabel
            // 
            this.LoginPasswordLabel.AutoSize = true;
            this.LoginPasswordLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.LoginPasswordLabel.Location = new System.Drawing.Point(198, 327);
            this.LoginPasswordLabel.Name = "LoginPasswordLabel";
            this.LoginPasswordLabel.Size = new System.Drawing.Size(76, 21);
            this.LoginPasswordLabel.TabIndex = 11;
            this.LoginPasswordLabel.Text = "Password";
            // 
            // LoginEmployeeNumberLabel
            // 
            this.LoginEmployeeNumberLabel.AutoSize = true;
            this.LoginEmployeeNumberLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.LoginEmployeeNumberLabel.Location = new System.Drawing.Point(198, 223);
            this.LoginEmployeeNumberLabel.Name = "LoginEmployeeNumberLabel";
            this.LoginEmployeeNumberLabel.Size = new System.Drawing.Size(140, 21);
            this.LoginEmployeeNumberLabel.TabIndex = 10;
            this.LoginEmployeeNumberLabel.Text = "Employee Number";
            // 
            // LoginPasswordTextBox
            // 
            this.LoginPasswordTextBox.Location = new System.Drawing.Point(200, 358);
            this.LoginPasswordTextBox.Name = "LoginPasswordTextBox";
            this.LoginPasswordTextBox.PasswordChar = '*';
            this.LoginPasswordTextBox.Size = new System.Drawing.Size(201, 23);
            this.LoginPasswordTextBox.TabIndex = 9;
            // 
            // LoginEmployeeNumberTextBox
            // 
            this.LoginEmployeeNumberTextBox.Location = new System.Drawing.Point(200, 257);
            this.LoginEmployeeNumberTextBox.Name = "LoginEmployeeNumberTextBox";
            this.LoginEmployeeNumberTextBox.Size = new System.Drawing.Size(201, 23);
            this.LoginEmployeeNumberTextBox.TabIndex = 8;
            // 
            // LogoLoginPanel
            // 
            this.LogoLoginPanel.Image = ((System.Drawing.Image)(resources.GetObject("LogoLoginPanel.Image")));
            this.LogoLoginPanel.Location = new System.Drawing.Point(416, 18);
            this.LogoLoginPanel.Name = "LogoLoginPanel";
            this.LogoLoginPanel.Size = new System.Drawing.Size(197, 96);
            this.LogoLoginPanel.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.LogoLoginPanel.TabIndex = 7;
            this.LogoLoginPanel.TabStop = false;
            // 
            // TitleLabelLoginPanel
            // 
            this.TitleLabelLoginPanel.AutoSize = true;
            this.TitleLabelLoginPanel.Font = new System.Drawing.Font("Segoe UI", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.TitleLabelLoginPanel.Location = new System.Drawing.Point(11, 32);
            this.TitleLabelLoginPanel.Name = "TitleLabelLoginPanel";
            this.TitleLabelLoginPanel.Size = new System.Drawing.Size(383, 47);
            this.TitleLabelLoginPanel.TabIndex = 6;
            this.TitleLabelLoginPanel.Text = "Restaurant Champeau";
            // 
            // WaiterHomePanel
            // 
            this.WaiterHomePanel.Controls.Add(this.TablesOverviewLogoWaiterPanel);
            this.WaiterHomePanel.Controls.Add(this.PaymentLogoWaiterPanel);
            this.WaiterHomePanel.Controls.Add(this.OrderLogoWaiterPanel);
            this.WaiterHomePanel.Controls.Add(this.NotifyLogoWaiterPanel);
            this.WaiterHomePanel.Controls.Add(this.LogOutButtonWaiterHomePanel);
            this.WaiterHomePanel.Controls.Add(this.PictureOfWaterHomePanel);
            this.WaiterHomePanel.Controls.Add(this.LogoWaiterHomePanel);
            this.WaiterHomePanel.Controls.Add(this.TitleWaiterHomePanel);
            this.WaiterHomePanel.Location = new System.Drawing.Point(1, 6);
            this.WaiterHomePanel.Name = "WaiterHomePanel";
            this.WaiterHomePanel.Size = new System.Drawing.Size(636, 693);
            this.WaiterHomePanel.TabIndex = 6;
            // 
            // TablesOverviewLogoWaiterPanel
            // 
            this.TablesOverviewLogoWaiterPanel.Image = ((System.Drawing.Image)(resources.GetObject("TablesOverviewLogoWaiterPanel.Image")));
            this.TablesOverviewLogoWaiterPanel.Location = new System.Drawing.Point(37, 391);
            this.TablesOverviewLogoWaiterPanel.Name = "TablesOverviewLogoWaiterPanel";
            this.TablesOverviewLogoWaiterPanel.Size = new System.Drawing.Size(140, 185);
            this.TablesOverviewLogoWaiterPanel.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.TablesOverviewLogoWaiterPanel.TabIndex = 17;
            this.TablesOverviewLogoWaiterPanel.TabStop = false;
            this.TablesOverviewLogoWaiterPanel.Click += new System.EventHandler(this.TablesOverviewLogoWaiterPanel_Click);
            // 
            // PaymentLogoWaiterPanel
            // 
            this.PaymentLogoWaiterPanel.Image = ((System.Drawing.Image)(resources.GetObject("PaymentLogoWaiterPanel.Image")));
            this.PaymentLogoWaiterPanel.Location = new System.Drawing.Point(482, 182);
            this.PaymentLogoWaiterPanel.Name = "PaymentLogoWaiterPanel";
            this.PaymentLogoWaiterPanel.Size = new System.Drawing.Size(132, 169);
            this.PaymentLogoWaiterPanel.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PaymentLogoWaiterPanel.TabIndex = 16;
            this.PaymentLogoWaiterPanel.TabStop = false;
            // 
            // OrderLogoWaiterPanel
            // 
            this.OrderLogoWaiterPanel.Image = ((System.Drawing.Image)(resources.GetObject("OrderLogoWaiterPanel.Image")));
            this.OrderLogoWaiterPanel.Location = new System.Drawing.Point(267, 182);
            this.OrderLogoWaiterPanel.Name = "OrderLogoWaiterPanel";
            this.OrderLogoWaiterPanel.Size = new System.Drawing.Size(143, 169);
            this.OrderLogoWaiterPanel.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.OrderLogoWaiterPanel.TabIndex = 15;
            this.OrderLogoWaiterPanel.TabStop = false;
            // 
            // NotifyLogoWaiterPanel
            // 
            this.NotifyLogoWaiterPanel.Image = ((System.Drawing.Image)(resources.GetObject("NotifyLogoWaiterPanel.Image")));
            this.NotifyLogoWaiterPanel.Location = new System.Drawing.Point(37, 182);
            this.NotifyLogoWaiterPanel.Name = "NotifyLogoWaiterPanel";
            this.NotifyLogoWaiterPanel.Size = new System.Drawing.Size(140, 169);
            this.NotifyLogoWaiterPanel.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.NotifyLogoWaiterPanel.TabIndex = 14;
            this.NotifyLogoWaiterPanel.TabStop = false;
            // 
            // LogOutButtonWaiterHomePanel
            // 
            this.LogOutButtonWaiterHomePanel.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.LogOutButtonWaiterHomePanel.Location = new System.Drawing.Point(487, 619);
            this.LogOutButtonWaiterHomePanel.Name = "LogOutButtonWaiterHomePanel";
            this.LogOutButtonWaiterHomePanel.Size = new System.Drawing.Size(119, 41);
            this.LogOutButtonWaiterHomePanel.TabIndex = 13;
            this.LogOutButtonWaiterHomePanel.Text = "Log out";
            this.LogOutButtonWaiterHomePanel.UseVisualStyleBackColor = true;
            this.LogOutButtonWaiterHomePanel.Click += new System.EventHandler(this.LogOutButtonWaiterHomePanel_Click);
            // 
            // PictureOfWaterHomePanel
            // 
            this.PictureOfWaterHomePanel.Image = ((System.Drawing.Image)(resources.GetObject("PictureOfWaterHomePanel.Image")));
            this.PictureOfWaterHomePanel.Location = new System.Drawing.Point(493, 19);
            this.PictureOfWaterHomePanel.Name = "PictureOfWaterHomePanel";
            this.PictureOfWaterHomePanel.Size = new System.Drawing.Size(123, 119);
            this.PictureOfWaterHomePanel.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PictureOfWaterHomePanel.TabIndex = 12;
            this.PictureOfWaterHomePanel.TabStop = false;
            // 
            // LogoWaiterHomePanel
            // 
            this.LogoWaiterHomePanel.Image = ((System.Drawing.Image)(resources.GetObject("LogoWaiterHomePanel.Image")));
            this.LogoWaiterHomePanel.Location = new System.Drawing.Point(250, 13);
            this.LogoWaiterHomePanel.Name = "LogoWaiterHomePanel";
            this.LogoWaiterHomePanel.Size = new System.Drawing.Size(197, 96);
            this.LogoWaiterHomePanel.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.LogoWaiterHomePanel.TabIndex = 11;
            this.LogoWaiterHomePanel.TabStop = false;
            // 
            // TitleWaiterHomePanel
            // 
            this.TitleWaiterHomePanel.AutoSize = true;
            this.TitleWaiterHomePanel.Font = new System.Drawing.Font("Segoe UI", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.TitleWaiterHomePanel.Location = new System.Drawing.Point(21, 15);
            this.TitleWaiterHomePanel.Name = "TitleWaiterHomePanel";
            this.TitleWaiterHomePanel.Size = new System.Drawing.Size(208, 94);
            this.TitleWaiterHomePanel.TabIndex = 10;
            this.TitleWaiterHomePanel.Text = "Restaurant \r\nChampeau";
            // 
            // TablesOverviewPanel
            // 
            this.TablesOverviewPanel.Controls.Add(this.BackButtonTablePanel);
            this.TablesOverviewPanel.Controls.Add(this.ModifyButton10);
            this.TablesOverviewPanel.Controls.Add(this.ModifyButton9);
            this.TablesOverviewPanel.Controls.Add(this.ModifyButton8);
            this.TablesOverviewPanel.Controls.Add(this.ModifyButton7);
            this.TablesOverviewPanel.Controls.Add(this.ModifyButton6);
            this.TablesOverviewPanel.Controls.Add(this.ModifyButton5);
            this.TablesOverviewPanel.Controls.Add(this.ModifyButton4);
            this.TablesOverviewPanel.Controls.Add(this.ModifyButton3);
            this.TablesOverviewPanel.Controls.Add(this.ModifyButton2);
            this.TablesOverviewPanel.Controls.Add(this.ModifyButton1);
            this.TablesOverviewPanel.Controls.Add(this.InstructionLabelTablePanel);
            this.TablesOverviewPanel.Controls.Add(this.LogoTablePanel);
            this.TablesOverviewPanel.Controls.Add(this.TitleTablePanel);
            this.TablesOverviewPanel.Controls.Add(this.TableButton10);
            this.TablesOverviewPanel.Controls.Add(this.TableButton9);
            this.TablesOverviewPanel.Controls.Add(this.TableButton8);
            this.TablesOverviewPanel.Controls.Add(this.TableButton7);
            this.TablesOverviewPanel.Controls.Add(this.TableButton6);
            this.TablesOverviewPanel.Controls.Add(this.TableButton5);
            this.TablesOverviewPanel.Controls.Add(this.TableButton4);
            this.TablesOverviewPanel.Controls.Add(this.TableButton3);
            this.TablesOverviewPanel.Controls.Add(this.TableButton2);
            this.TablesOverviewPanel.Controls.Add(this.TableButton1);
            this.TablesOverviewPanel.Location = new System.Drawing.Point(1, 12);
            this.TablesOverviewPanel.Name = "TablesOverviewPanel";
            this.TablesOverviewPanel.Size = new System.Drawing.Size(639, 696);
            this.TablesOverviewPanel.TabIndex = 6;
            // 
            // BackButtonTablePanel
            // 
            this.BackButtonTablePanel.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.BackButtonTablePanel.Location = new System.Drawing.Point(250, 643);
            this.BackButtonTablePanel.Name = "BackButtonTablePanel";
            this.BackButtonTablePanel.Size = new System.Drawing.Size(119, 33);
            this.BackButtonTablePanel.TabIndex = 23;
            this.BackButtonTablePanel.Text = "Back";
            this.BackButtonTablePanel.UseVisualStyleBackColor = true;
            this.BackButtonTablePanel.Click += new System.EventHandler(this.BackButtonTablePanel_Click);
            // 
            // ModifyButton10
            // 
            this.ModifyButton10.Font = new System.Drawing.Font("Segoe UI", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.ModifyButton10.Location = new System.Drawing.Point(486, 579);
            this.ModifyButton10.Name = "ModifyButton10";
            this.ModifyButton10.Size = new System.Drawing.Size(86, 31);
            this.ModifyButton10.TabIndex = 22;
            this.ModifyButton10.Text = "Modify";
            this.ModifyButton10.UseVisualStyleBackColor = true;
            // 
            // ModifyButton9
            // 
            this.ModifyButton9.Font = new System.Drawing.Font("Segoe UI", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.ModifyButton9.Location = new System.Drawing.Point(166, 579);
            this.ModifyButton9.Name = "ModifyButton9";
            this.ModifyButton9.Size = new System.Drawing.Size(86, 31);
            this.ModifyButton9.TabIndex = 21;
            this.ModifyButton9.Text = "Modify";
            this.ModifyButton9.UseVisualStyleBackColor = true;
            // 
            // ModifyButton8
            // 
            this.ModifyButton8.Font = new System.Drawing.Font("Segoe UI", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.ModifyButton8.Location = new System.Drawing.Point(488, 469);
            this.ModifyButton8.Name = "ModifyButton8";
            this.ModifyButton8.Size = new System.Drawing.Size(86, 31);
            this.ModifyButton8.TabIndex = 20;
            this.ModifyButton8.Text = "Modify";
            this.ModifyButton8.UseVisualStyleBackColor = true;
            // 
            // ModifyButton7
            // 
            this.ModifyButton7.Font = new System.Drawing.Font("Segoe UI", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.ModifyButton7.Location = new System.Drawing.Point(166, 469);
            this.ModifyButton7.Name = "ModifyButton7";
            this.ModifyButton7.Size = new System.Drawing.Size(86, 31);
            this.ModifyButton7.TabIndex = 19;
            this.ModifyButton7.Text = "Modify";
            this.ModifyButton7.UseVisualStyleBackColor = true;
            // 
            // ModifyButton6
            // 
            this.ModifyButton6.Font = new System.Drawing.Font("Segoe UI", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.ModifyButton6.Location = new System.Drawing.Point(488, 355);
            this.ModifyButton6.Name = "ModifyButton6";
            this.ModifyButton6.Size = new System.Drawing.Size(86, 31);
            this.ModifyButton6.TabIndex = 18;
            this.ModifyButton6.Text = "Modify";
            this.ModifyButton6.UseVisualStyleBackColor = true;
            // 
            // ModifyButton5
            // 
            this.ModifyButton5.Font = new System.Drawing.Font("Segoe UI", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.ModifyButton5.Location = new System.Drawing.Point(166, 355);
            this.ModifyButton5.Name = "ModifyButton5";
            this.ModifyButton5.Size = new System.Drawing.Size(86, 31);
            this.ModifyButton5.TabIndex = 17;
            this.ModifyButton5.Text = "Modify";
            this.ModifyButton5.UseVisualStyleBackColor = true;
            // 
            // ModifyButton4
            // 
            this.ModifyButton4.Font = new System.Drawing.Font("Segoe UI", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.ModifyButton4.Location = new System.Drawing.Point(488, 243);
            this.ModifyButton4.Name = "ModifyButton4";
            this.ModifyButton4.Size = new System.Drawing.Size(86, 31);
            this.ModifyButton4.TabIndex = 16;
            this.ModifyButton4.Text = "Modify";
            this.ModifyButton4.UseVisualStyleBackColor = true;
            // 
            // ModifyButton3
            // 
            this.ModifyButton3.Font = new System.Drawing.Font("Segoe UI", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.ModifyButton3.Location = new System.Drawing.Point(166, 245);
            this.ModifyButton3.Name = "ModifyButton3";
            this.ModifyButton3.Size = new System.Drawing.Size(86, 31);
            this.ModifyButton3.TabIndex = 15;
            this.ModifyButton3.Text = "Modify";
            this.ModifyButton3.UseVisualStyleBackColor = true;
            // 
            // ModifyButton2
            // 
            this.ModifyButton2.Font = new System.Drawing.Font("Segoe UI", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.ModifyButton2.Location = new System.Drawing.Point(488, 136);
            this.ModifyButton2.Name = "ModifyButton2";
            this.ModifyButton2.Size = new System.Drawing.Size(86, 31);
            this.ModifyButton2.TabIndex = 14;
            this.ModifyButton2.Text = "Modify";
            this.ModifyButton2.UseVisualStyleBackColor = true;
            // 
            // ModifyButton1
            // 
            this.ModifyButton1.Font = new System.Drawing.Font("Segoe UI", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.ModifyButton1.Location = new System.Drawing.Point(166, 136);
            this.ModifyButton1.Name = "ModifyButton1";
            this.ModifyButton1.Size = new System.Drawing.Size(86, 31);
            this.ModifyButton1.TabIndex = 13;
            this.ModifyButton1.Text = "Modify";
            this.ModifyButton1.UseVisualStyleBackColor = true;
            // 
            // InstructionLabelTablePanel
            // 
            this.InstructionLabelTablePanel.AutoSize = true;
            this.InstructionLabelTablePanel.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            this.InstructionLabelTablePanel.Location = new System.Drawing.Point(34, 69);
            this.InstructionLabelTablePanel.Name = "InstructionLabelTablePanel";
            this.InstructionLabelTablePanel.Size = new System.Drawing.Size(247, 40);
            this.InstructionLabelTablePanel.TabIndex = 12;
            this.InstructionLabelTablePanel.Text = "Klik op een tafel om de status te \nveranderen als de rekening is betaald.";
            // 
            // LogoTablePanel
            // 
            this.LogoTablePanel.Image = ((System.Drawing.Image)(resources.GetObject("LogoTablePanel.Image")));
            this.LogoTablePanel.Location = new System.Drawing.Point(433, 9);
            this.LogoTablePanel.Name = "LogoTablePanel";
            this.LogoTablePanel.Size = new System.Drawing.Size(192, 97);
            this.LogoTablePanel.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.LogoTablePanel.TabIndex = 11;
            this.LogoTablePanel.TabStop = false;
            // 
            // TitleTablePanel
            // 
            this.TitleTablePanel.AutoSize = true;
            this.TitleTablePanel.Font = new System.Drawing.Font("Segoe UI", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.TitleTablePanel.Location = new System.Drawing.Point(22, 15);
            this.TitleTablePanel.Name = "TitleTablePanel";
            this.TitleTablePanel.Size = new System.Drawing.Size(383, 47);
            this.TitleTablePanel.TabIndex = 10;
            this.TitleTablePanel.Text = "Restaurant Champeau";
            // 
            // TableButton10
            // 
            this.TableButton10.BackColor = System.Drawing.Color.LawnGreen;
            this.TableButton10.Font = new System.Drawing.Font("Segoe UI", 40F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TableButton10.Location = new System.Drawing.Point(375, 548);
            this.TableButton10.Name = "TableButton10";
            this.TableButton10.Size = new System.Drawing.Size(98, 94);
            this.TableButton10.TabIndex = 9;
            this.TableButton10.Text = "10";
            this.TableButton10.UseVisualStyleBackColor = false;
            // 
            // TableButton9
            // 
            this.TableButton9.BackColor = System.Drawing.Color.LawnGreen;
            this.TableButton9.Font = new System.Drawing.Font("Segoe UI", 40F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TableButton9.Location = new System.Drawing.Point(48, 548);
            this.TableButton9.Name = "TableButton9";
            this.TableButton9.Size = new System.Drawing.Size(98, 94);
            this.TableButton9.TabIndex = 8;
            this.TableButton9.Text = "9";
            this.TableButton9.UseVisualStyleBackColor = false;
            // 
            // TableButton8
            // 
            this.TableButton8.BackColor = System.Drawing.Color.LawnGreen;
            this.TableButton8.Font = new System.Drawing.Font("Segoe UI", 40F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TableButton8.Location = new System.Drawing.Point(375, 436);
            this.TableButton8.Name = "TableButton8";
            this.TableButton8.Size = new System.Drawing.Size(98, 94);
            this.TableButton8.TabIndex = 7;
            this.TableButton8.Text = "8";
            this.TableButton8.UseVisualStyleBackColor = false;
            // 
            // TableButton7
            // 
            this.TableButton7.BackColor = System.Drawing.Color.LawnGreen;
            this.TableButton7.Font = new System.Drawing.Font("Segoe UI", 40F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TableButton7.Location = new System.Drawing.Point(48, 436);
            this.TableButton7.Name = "TableButton7";
            this.TableButton7.Size = new System.Drawing.Size(98, 94);
            this.TableButton7.TabIndex = 6;
            this.TableButton7.Text = "7";
            this.TableButton7.UseVisualStyleBackColor = false;
            // 
            // TableButton6
            // 
            this.TableButton6.BackColor = System.Drawing.Color.LawnGreen;
            this.TableButton6.Font = new System.Drawing.Font("Segoe UI", 40F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TableButton6.Location = new System.Drawing.Point(375, 322);
            this.TableButton6.Name = "TableButton6";
            this.TableButton6.Size = new System.Drawing.Size(98, 94);
            this.TableButton6.TabIndex = 5;
            this.TableButton6.Text = "6";
            this.TableButton6.UseVisualStyleBackColor = false;
            // 
            // TableButton5
            // 
            this.TableButton5.BackColor = System.Drawing.Color.LawnGreen;
            this.TableButton5.Font = new System.Drawing.Font("Segoe UI", 40F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TableButton5.Location = new System.Drawing.Point(48, 322);
            this.TableButton5.Name = "TableButton5";
            this.TableButton5.Size = new System.Drawing.Size(98, 94);
            this.TableButton5.TabIndex = 4;
            this.TableButton5.Text = "5";
            this.TableButton5.UseVisualStyleBackColor = false;
            // 
            // TableButton4
            // 
            this.TableButton4.BackColor = System.Drawing.Color.LawnGreen;
            this.TableButton4.Font = new System.Drawing.Font("Segoe UI", 40F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TableButton4.Location = new System.Drawing.Point(375, 216);
            this.TableButton4.Name = "TableButton4";
            this.TableButton4.Size = new System.Drawing.Size(98, 94);
            this.TableButton4.TabIndex = 3;
            this.TableButton4.Text = "4";
            this.TableButton4.UseVisualStyleBackColor = false;
            // 
            // TableButton3
            // 
            this.TableButton3.BackColor = System.Drawing.Color.LawnGreen;
            this.TableButton3.Font = new System.Drawing.Font("Segoe UI", 40F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TableButton3.Location = new System.Drawing.Point(48, 216);
            this.TableButton3.Name = "TableButton3";
            this.TableButton3.Size = new System.Drawing.Size(98, 94);
            this.TableButton3.TabIndex = 2;
            this.TableButton3.Text = "3";
            this.TableButton3.UseVisualStyleBackColor = false;
            // 
            // TableButton2
            // 
            this.TableButton2.BackColor = System.Drawing.Color.LawnGreen;
            this.TableButton2.Font = new System.Drawing.Font("Segoe UI", 40F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TableButton2.Location = new System.Drawing.Point(375, 109);
            this.TableButton2.Name = "TableButton2";
            this.TableButton2.Size = new System.Drawing.Size(98, 94);
            this.TableButton2.TabIndex = 1;
            this.TableButton2.Text = "2";
            this.TableButton2.UseVisualStyleBackColor = false;
            // 
            // TableButton1
            // 
            this.TableButton1.BackColor = System.Drawing.Color.LawnGreen;
            this.TableButton1.Font = new System.Drawing.Font("Segoe UI", 40F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.TableButton1.Location = new System.Drawing.Point(48, 108);
            this.TableButton1.Name = "TableButton1";
            this.TableButton1.Size = new System.Drawing.Size(98, 94);
            this.TableButton1.TabIndex = 0;
            this.TableButton1.Text = "1";
            this.TableButton1.UseVisualStyleBackColor = false;
            // 
            // ProjectChapeau
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(643, 700);
            this.Controls.Add(this.TablesOverviewPanel);
            this.Controls.Add(this.WaiterHomePanel);
            this.Controls.Add(this.ManagerHomePanel);
            this.Controls.Add(this.HomePanel);
            this.Controls.Add(this.LoginPanel);
            this.Name = "ProjectChapeau";
            this.Text = "ProjectChapeau";
            this.Load += new System.EventHandler(this.ProjectChapeau_Load);
            this.HomePanel.ResumeLayout(false);
            this.HomePanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LogoHomePanel)).EndInit();
            this.ManagerHomePanel.ResumeLayout(false);
            this.ManagerHomePanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AdjustMenuLogoManagerHomePanel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.AddEmployeeLogoManagerHomePanel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SuppliesLogoManagerHomePanel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureOfManagerHomePanel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LogoManagerHomePanel)).EndInit();
            this.LoginPanel.ResumeLayout(false);
            this.LoginPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LogoLoginPanel)).EndInit();
            this.WaiterHomePanel.ResumeLayout(false);
            this.WaiterHomePanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TablesOverviewLogoWaiterPanel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PaymentLogoWaiterPanel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.OrderLogoWaiterPanel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NotifyLogoWaiterPanel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureOfWaterHomePanel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LogoWaiterHomePanel)).EndInit();
            this.TablesOverviewPanel.ResumeLayout(false);
            this.TablesOverviewPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LogoTablePanel)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private Panel HomePanel;
        private Button LoginButtonHomePanel;
        private Label TitleLabelHomePanel;
        private PictureBox LogoHomePanel;
        private Panel LoginPanel;
        private PictureBox LogoLoginPanel;
        private Label TitleLabelLoginPanel;
        private Button ContinueButtonLoginPanel;
        private Button CancelButtonLoginPanel;
        private Label LoginPasswordLabel;
        private Label LoginEmployeeNumberLabel;
        private TextBox LoginPasswordTextBox;
        private TextBox LoginEmployeeNumberTextBox;
        private Panel ManagerHomePanel;
        private PictureBox PictureOfManagerHomePanel;
        private PictureBox LogoManagerHomePanel;
        private Label TitleManagerHomePanel;
        private Button LogoutButtonManagerHomePanel;
        private PictureBox SuppliesLogoManagerHomePanel;
        private PictureBox AdjustMenuLogoManagerHomePanel;
        private PictureBox AddEmployeeLogoManagerHomePanel;
        private Panel WaiterHomePanel;
        private PictureBox TablesOverviewLogoWaiterPanel;
        private PictureBox PaymentLogoWaiterPanel;
        private PictureBox OrderLogoWaiterPanel;
        private PictureBox NotifyLogoWaiterPanel;
        private Button LogOutButtonWaiterHomePanel;
        private PictureBox PictureOfWaterHomePanel;
        private PictureBox LogoWaiterHomePanel;
        private Label TitleWaiterHomePanel;
        private Panel TablesOverviewPanel;
        private Label InstructionLabelTablePanel;
        private PictureBox LogoTablePanel;
        private Label TitleTablePanel;
        private Button TableButton10;
        private Button TableButton9;
        private Button TableButton8;
        private Button TableButton7;
        private Button TableButton6;
        private Button TableButton5;
        private Button TableButton4;
        private Button TableButton3;
        private Button TableButton2;
        private Button TableButton1;
        private Button ModifyButton10;
        private Button ModifyButton9;
        private Button ModifyButton8;
        private Button ModifyButton7;
        private Button ModifyButton6;
        private Button ModifyButton5;
        private Button ModifyButton4;
        private Button ModifyButton3;
        private Button ModifyButton2;
        private Button ModifyButton1;
        private Button BackButtonTablePanel;
    }
}