using DAL;
using Model;
using Service;
using static System.Windows.Forms.LinkLabel;

namespace UI
{
    public partial class ProjectChapeau : Form
    {
        private Button[] tableButtons;
        private MedewerkerService medewerkerService;
        public ProjectChapeau()
        {
            InitializeComponent();
            tableButtons = new Button[] { TableButton1, TableButton2, TableButton3, TableButton4, TableButton5,
                                  TableButton6, TableButton7, TableButton8, TableButton9, TableButton10 };

            medewerkerService = new MedewerkerService();
        }
        private void HideAllPanels()
        {
            LoginPanel.Hide();
            TablesPanel.Hide();
            TableStatusPanel.Hide();
            
        }
        private void ProjectChapeau_Load(object sender, EventArgs e)
        {
            

        }

        private void LoginButtonLoginPanel_Click(object sender, EventArgs e)
        {
            HideAllPanels();

            string employeeNumber = LoginEmployeeNumberTextBox.Text;
            string password = LoginPasswordTextBox.Text;

            MedewerkerService medewerkerService = new MedewerkerService();
            List<Medewerker> medewerkers = medewerkerService.GetMedewerkers();

            Medewerker foundMedewerker = null;

            foreach (Medewerker medewerker in medewerkers)
            {
                if (medewerker.MedewerkerNummer.ToString() == employeeNumber && "Welkom12" == password)
                {
                    foundMedewerker = medewerker;
                    break;
                }
            }

            if (foundMedewerker != null)
            {
                switch (foundMedewerker.Functie)
                {
                    case "Manager":
                        // Code voor het tonen van het Manager-panel
                        break;
                    case "Chef":
                        // Code voor het tonen van het Chef-panel
                        break;
                    case "Barman":
                        // Code voor het tonen van het Barman-panel
                        break;
                    default:
                        LoginPanel.Show();
                        break;
                }
            }
            else
            {
                MessageBox.Show("Ongeldige gebruikersnaam of wachtwoord.");
            }
        }

        private void BackButtonTablePanel_Click(object sender, EventArgs e)
        {
            HideAllPanels();
            LoginPanel.Show();
        }

        private void BackButtonTableStatusPanel_Click(object sender, EventArgs e)
        {
            HideAllPanels();
            TablesPanel.Show();
        }

        private void ForgotPasswordLabelLoginPanel_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Please contact the manager");
        }

        private void FreeButtonTableStatusPanel_Click(object sender, EventArgs e)
        {
            int tableNumber = int.Parse(TableNumberAnswerStatusPanel.Text);
            tableButtons[tableNumber - 1].BackColor = Color.LawnGreen;
            FreeButtonTableStatusPanel.FlatStyle = FlatStyle.Flat;
        }
        private void OccupiedButtonTableStatusPanel_Click(object sender, EventArgs e)
        {
            int tableNumber = int.Parse(TableNumberAnswerStatusPanel.Text);
            tableButtons[tableNumber - 1].BackColor = Color.Orange;
            OccupiedButtonTableStatusPanel.FlatStyle = FlatStyle.Flat;
        }

        private void ReservedButtonTableStatusPanel_Click(object sender, EventArgs e)
        {
            int tableNumber = int.Parse(TableNumberAnswerStatusPanel.Text);
            tableButtons[tableNumber - 1].BackColor = Color.Silver;
            ReservedButtonTableStatusPanel.FlatStyle = FlatStyle.Flat;
        }
        private void TableButton1_Click(object sender, EventArgs e)
        {

            TableNumberAnswerStatusPanel.Text = "1";
            HideAllPanels();
            TableStatusPanel.Show();
        }
        private void TableButton2_Click(object sender, EventArgs e)
        {
            TableNumberAnswerStatusPanel.Text = "2";
            HideAllPanels();
            TableStatusPanel.Show();
            
        }

        private void TableButton3_Click(object sender, EventArgs e)
        {
            TableNumberAnswerStatusPanel.Text = "3";
            HideAllPanels();
            TableStatusPanel.Show();
        }

        private void TableButton4_Click(object sender, EventArgs e)
        {
            TableNumberAnswerStatusPanel.Text = "4";
            HideAllPanels();
            TableStatusPanel.Show();
        }

        private void TableButton5_Click(object sender, EventArgs e)
        {
            TableNumberAnswerStatusPanel.Text = "5";
            HideAllPanels();
            TableStatusPanel.Show();
        }

        private void TableButton6_Click(object sender, EventArgs e)
        {
            TableNumberAnswerStatusPanel.Text = "6";
            HideAllPanels();
            TableStatusPanel.Show();
        }

        private void TableButton7_Click(object sender, EventArgs e)
        {
            TableNumberAnswerStatusPanel.Text = "7";
            HideAllPanels();
            TableStatusPanel.Show();
        }

        private void TableButton8_Click(object sender, EventArgs e)
        {
            TableNumberAnswerStatusPanel.Text = "8";
            HideAllPanels();
            TableStatusPanel.Show();
        }
        private void TableButton9_Click(object sender, EventArgs e)
        {
            TableNumberAnswerStatusPanel.Text = "9";
            HideAllPanels();
            TableStatusPanel.Show();
        }
        private void TableButton10_Click(object sender, EventArgs e)
        {
            TableNumberAnswerStatusPanel.Text = "10";
            HideAllPanels();
            TableStatusPanel.Show();
        }


        private void GoToTableButtonTableStatusPanel_Click(object sender, EventArgs e)
        {
            // Gaat naar de orders panel
        }

        
    }
}