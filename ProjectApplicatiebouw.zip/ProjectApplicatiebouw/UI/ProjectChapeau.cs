using DAL;
using Model;
using Service;
using static System.Windows.Forms.LinkLabel;

namespace UI
{
    public partial class ProjectChapeau : Form
    {

        private BestellingService bestellingService;
        private int currentBestellingId;

        public ProjectChapeau()
        {
            InitializeComponent();


            // Maak een instantie van de BestellingService
            bestellingService = new BestellingService();

            // Haal het huidige hoogste bestellingId op uit de database
            currentBestellingId = bestellingService.GetHighestBestellingId() + 1;

        }

        private void ProjectChapeau_Load(object sender, EventArgs e)
        {

            

            
        }

        private void AddItem_Click(object sender, EventArgs e)
        {
            // Verkrijg de invoer van de gebruiker
            int tafelnummer = Convert.ToInt32(TafelNummer.Text);
            int klantnummer = Convert.ToInt32(KlantNummer.Text);
            DateTime bestellingTijd = DateTime.Now;

            // Maak een nieuwe bestelling
            Bestelling bestelling = new Bestelling
            {
                BestellingNummer = currentBestellingId,
                TafelNummer = tafelnummer,
                KlantNummer = klantnummer,
                Tijd = bestellingTijd
            };

            // Voeg de bestelling toe aan de database via de BestellingService
            bestellingService.AddBestelling(bestelling);

            // Verhoog het huidige bestellingId met 1 voor de volgende bestelling
            currentBestellingId++;

            // Toon de bestelling in de UI
            ShowOrderDetails(bestelling);
        }

        private void ShowOrderDetails(Bestelling bestelling)
        {
            // Toon de bestelling in de UI
            label1.Text = $"Bestelling ID: {bestelling.BestellingNummer}\n";
            label1.Text += $"Tafelnummer: {bestelling.TafelNummer}\n";
            label1.Text += $"Klantnummer: {bestelling.KlantNummer}\n";
            label1.Text += $"Bestelling Tijd: {bestelling.Tijd}\n";
        }
    }
}