using DAL;
using Model;
using Service;
using static System.Windows.Forms.LinkLabel;

namespace UI
{
    public partial class ProjectChapeau : Form
    {

        private BestellingService bestellingService;
        private int currentBestellingId;

        public ProjectChapeau()
        {
            InitializeComponent();

            HomePanel.BringToFront();
        }
        private void HideAllPanels()
        {
            HomePanel.Hide();
            LoginPanel.Hide();
            ManagerHomePanel.Hide();
            WaiterHomePanel.Hide();
            TablesOverviewPanel.Hide();
        }
        private void ProjectChapeau_Load(object sender, EventArgs e)
        {
            

        }

        private void LoginButtonHomePanel_Click(object sender, EventArgs e)
        {
            HideAllPanels();
            LoginPanel.Show();
        }
        private void CancelButtonLoginPanel_Click(object sender, EventArgs e)
        {
            HideAllPanels();
            HomePanel.Show();
        }

        private void ContinueButtonLoginPanel_Click(object sender, EventArgs e)
        {
            HideAllPanels();

            if (LoginEmployeeNumberTextBox.Text == "1" && LoginPasswordTextBox.Text == "Welkom12")
            {
                
                ManagerHomePanel.Show();
            }
            else if (LoginEmployeeNumberTextBox.Text == "2" && LoginPasswordTextBox.Text == "Welkom12")
            {
                //panel van Chef moet hier komen .Show()
            }
            else if (LoginEmployeeNumberTextBox.Text == "3" && LoginPasswordTextBox.Text == "Welkom12")
            {
                //panel van Barman moet hier komen .Show()
            }
            else if (LoginEmployeeNumberTextBox.Text == "4" && LoginPasswordTextBox.Text == "Welkom12")
            {
                WaiterHomePanel.Show();
            }
            else
            {
                MessageBox.Show("Invalid UserName or Password.");
            }
            
           
        }

        private void LogoutButtonManagerHomePanel_Click(object sender, EventArgs e)
        {
            HideAllPanels();
            HomePanel.Show();
        }

        private void LogOutButtonWaiterHomePanel_Click(object sender, EventArgs e)
        {
            HideAllPanels();
            HomePanel.Show();
        }

        private void BackButtonTablePanel_Click(object sender, EventArgs e)
        {
            HideAllPanels();
            WaiterHomePanel.Show();
        }

        private void TablesOverviewLogoWaiterPanel_Click(object sender, EventArgs e)
        {
            HideAllPanels();
            TablesOverviewPanel.Show();
        }
    }
}