﻿using Model;
using Service;

namespace UI
{
    internal class Program
    {
        static void Main(string[] args)
        {

            // get and display all drinks
            List<Drink> drinks = GetDrinks();
            DisplayDrinks(drinks);

        }

        // Getting all the drinks using drinksService
        private static List<Drink> GetDrinks()
        {
            DrinkService drinksService = new DrinkService();
            List<Drink> drinks = drinksService.GetDrinks();
            return drinks;
        }
        private static void DisplayDrinks(List<Drink> drinks)
        {
           

            foreach (Drink drink in drinks)
            {
                Console.WriteLine(drink.DrinkID);
                Console.WriteLine(drink.DrinkName);


            }
        }
    }

}
