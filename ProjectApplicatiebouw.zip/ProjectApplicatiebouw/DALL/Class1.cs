﻿namespace DALL
{
    public class Class1
    {

    }
}