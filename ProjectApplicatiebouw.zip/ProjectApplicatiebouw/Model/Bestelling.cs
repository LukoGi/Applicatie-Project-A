﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class Bestelling
    {
        public int BestellingNummer { get; set; }
        public int TafelNummer { get; set; }
        public int KlantNummer { get; set; }
        public DateTime Tijd { get; set; }
    }
}
