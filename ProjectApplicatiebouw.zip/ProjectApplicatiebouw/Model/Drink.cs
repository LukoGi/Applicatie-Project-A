﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class Drink
    {
        public int DrinkID { get; set; }                 // database id
        public string DrinkName { get; set; }       // Name of drink
    }
}
