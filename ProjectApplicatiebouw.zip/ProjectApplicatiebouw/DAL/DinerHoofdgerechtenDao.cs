﻿using Model;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class DinerHoofdgerechtenDao : BaseDao
    {
        private SqlConnection dbConnection;

        //make connection with the database
        public DinerHoofdgerechtenDao()
        {
            string connString = ConfigurationManager.
                ConnectionStrings["ChapeauDatabase"].ConnectionString;
            dbConnection = new SqlConnection(connString);
        }

        // get all the DinerHoofdgerechten from the list
        public List<DinerHoofdgerechten> GetAllDinerHoofdgerechten()
        {
            string query = "SELECT HoofdgerechtID, Naam, Prijs FROM DinerHoofdgerechten";
            SqlParameter[] sqlParameters = new SqlParameter[0];
            return ReadTables(ExecuteSelectQuery(query, sqlParameters));
        }

        // read the tables from the database
        private List<DinerHoofdgerechten> ReadTables(DataTable dataTable)
        {
            List<DinerHoofdgerechten> dinerHoofdgerechtenList = new List<DinerHoofdgerechten>();

            if (dataTable == null)
                throw new Exception("Datatable is leeg");

            foreach (DataRow dr in dataTable.Rows)
            {
                DinerHoofdgerechten dinerHoofdgerechten = new DinerHoofdgerechten()
                {
                    HoofdgerechtID = (int)dr["HoofdgerechtID"],
                    Naam = (string)dr["Naam"],
                    Prijs = (decimal)dr["Prijs"],

                };
                dinerHoofdgerechtenList.Add(dinerHoofdgerechten);
            }
            if (dinerHoofdgerechtenList.Count == 0)
                throw new Exception("There are no drinks");

            return dinerHoofdgerechtenList;
        }



    }
}
