﻿using Model;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class BestellingDao : BaseDao
    {
        private SqlConnection dbConnection;

        // Maak verbinding met de database
        public BestellingDao()
        {
            string connString = ConfigurationManager.ConnectionStrings["ChapeauDatabase"].ConnectionString;
            dbConnection = new SqlConnection(connString);
        }


        // Lees de bestellingen uit de database
        private List<Bestelling> ReadBestellingen(DataTable dataTable)
        {
            List<Bestelling> bestellingen = new List<Bestelling>();

            if (dataTable == null)
                throw new Exception("Datatable is leeg");

            foreach (DataRow dr in dataTable.Rows)
            {
                Bestelling bestelling = new Bestelling()
                {
                    BestellingNummer = (int)dr["BestellingNummer"],
                    TafelNummer = (int)dr["TafelNummer"],
                    KlantNummer = (int)dr["KlantNummer"],
                    Tijd = (DateTime)dr["Tijd"]
                };
                bestellingen.Add(bestelling);
            }
            if (bestellingen.Count == 0)
                throw new Exception("Er zijn geen bestellingen gevonden");

            return bestellingen;
        }

        // Haal alle bestellingen op uit de database
        public List<Bestelling> GetAllBestellingen()
        {
            string query = "SELECT BestellingNummer, TafelNummer, KlantNummer, Tijd FROM Bestelling";
            SqlParameter[] sqlParameters = new SqlParameter[0];
            return ReadBestellingen(ExecuteSelectQuery(query, sqlParameters));
        }

        // Voeg een nieuwe bestelling toe aan de database
        public void AddBestelling(Bestelling bestelling)
        {
            string query = "INSERT INTO Bestelling (BestellingNummer, TafelNummer, KlantNummer, Tijd) " +
                           "VALUES (@BestellingNummer, @TafelNummer, @KlantNummer, @Tijd)";
            try
            {
                dbConnection.Open();
                SqlCommand command = new SqlCommand(query, dbConnection);
                command.Parameters.AddWithValue("@BestellingNummer", bestelling.BestellingNummer);
                command.Parameters.AddWithValue("@TafelNummer", bestelling.TafelNummer);
                command.Parameters.AddWithValue("@KlantNummer", bestelling.KlantNummer);
                command.Parameters.AddWithValue("@Tijd", bestelling.Tijd);
                command.ExecuteNonQuery();
            }
            catch
            {
                throw new Exception("Can not connect to the database");
            }
            finally
            {
                dbConnection.Close();
            }
        }

    }
}
