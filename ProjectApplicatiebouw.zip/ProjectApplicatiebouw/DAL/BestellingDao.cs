﻿using Model;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class BestellingDao : BaseDao
    {
        private SqlConnection dbConnection;

        // Maak verbinding met de database
        public BestellingDao()
        {
            string connString = ConfigurationManager.ConnectionStrings["ChapeauDatabase"].ConnectionString;
            dbConnection = new SqlConnection(connString);
        }


        // Lees de bestellingen uit de database
        private List<Bestelling> ReadBestellingen(DataTable dataTable)
        {
            List<Bestelling> bestellingen = new List<Bestelling>();

            if (dataTable == null)
                throw new Exception("Datatable is leeg");

            foreach (DataRow dr in dataTable.Rows)
            {
                Bestelling bestelling = new Bestelling()
                {
                    BestellingNummer = (int)dr["BestellingNummer"],
                    TafelNummer = (int)dr["TafelNummer"],
                    KlantNummer = (int)dr["KlantNummer"],
                    Tijd = (DateTime)dr["Tijd"]
                };
                bestellingen.Add(bestelling);
            }
            if (bestellingen.Count == 0)
                throw new Exception("Er zijn geen bestellingen gevonden");

            return bestellingen;
        }

        // Haal alle bestellingen op uit de database
        public List<Bestelling> GetAllBestellingen()
        {
            string query = "SELECT BestellingNummer, TafelNummer, KlantNummer, Tijd FROM Bestelling";
            SqlParameter[] sqlParameters = new SqlParameter[0];
            return ReadBestellingen(ExecuteSelectQuery(query, sqlParameters));
        }

        // Voeg een nieuwe bestelling toe aan de database
        public void AddBestelling(Bestelling bestelling)
        {
            string query = "INSERT INTO Bestelling (BestellingNummer, TafelNummer, KlantNummer, Tijd) " +
                           "VALUES (@BestellingNummer, @TafelNummer, @KlantNummer, @Tijd)";
            SqlParameter[] sqlParameters = new SqlParameter[]
            {
            new SqlParameter("@BestellingNummer", bestelling.BestellingNummer),
            new SqlParameter("@TafelNummer", bestelling.TafelNummer),
            new SqlParameter("@KlantNummer", bestelling.KlantNummer),
            new SqlParameter("@Tijd", bestelling.Tijd)
            };

            //Lees het uit en push hem door naar de database
            ExecuteEditQuery(query, sqlParameters);
        }

        // Haal alle bestellingen op uit de database en bereken het hoogste bestellings-ID
        // Haal alle bestellingen op uit de database en bereken het hoogste bestellings-ID
        public int GetHighestBestellingId()
        {
            string query = "SELECT MAX(BestellingNummer) FROM Bestelling";
            SqlParameter[] sqlParameters = new SqlParameter[0];
            DataTable resultTable = ExecuteSelectQuery(query, sqlParameters);

            if (resultTable != null && resultTable.Rows.Count > 0 && resultTable.Rows[0][0] != DBNull.Value)
            {
                return Convert.ToInt32(resultTable.Rows[0][0]);
            }

            return 0; // Geen bestellingen gevonden, begin met 0 als het hoogste bestellings-ID
        }

    }
}
