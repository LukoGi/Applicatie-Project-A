﻿using Model;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class TafelsDao : BaseDao
    {
        private SqlConnection dbConnection;

        // Maak verbinding met de database
        public TafelsDao()
        {
            string connString = ConfigurationManager.ConnectionStrings["ChapeauDatabase"].ConnectionString;
            dbConnection = new SqlConnection(connString);
        }

        // Lees de tafels uit de database
        private List<Tafels> ReadTafels(DataTable dataTable)
        {
            List<Tafels> tafels = new List<Tafels>();

            if (dataTable == null)
                throw new Exception("Datatable is leeg");

            foreach (DataRow dr in dataTable.Rows)
            {
                Tafels tafel = new Tafels()
                {
                    TafelNummer = (int)dr["TafelNummer"],
                    MedewerkerNummer = (int)dr["MedewerkerNummer"],
                    KlantNummer = (int)dr["KlantNummer"]
                };
                tafels.Add(tafel);
            }

            return tafels;
        }

        // Haal alle tafels op uit de database
        public List<Tafels> GetAllTafels()
        {
            string query = "SELECT TafelNummer, MedewerkerNummer, KlantNummer FROM Tafel";
            SqlParameter[] sqlParameters = new SqlParameter[0];
            return ReadTafels(ExecuteSelectQuery(query, sqlParameters));
        }
    }
}
