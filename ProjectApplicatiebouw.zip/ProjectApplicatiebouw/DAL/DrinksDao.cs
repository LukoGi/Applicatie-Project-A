﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;

namespace DAL
{
    public class DrinksDao : BaseDao
    {
        private SqlConnection dbConnection;

        public DrinksDao()
        {
            string connString = ConfigurationManager.
                ConnectionStrings["ChapeauDatabase"].ConnectionString;
            dbConnection = new SqlConnection(connString);
        }

        public List<Drink> GetAllDrinks()
        {
            string query = "SELECT DrinkId, DrinkName FROM Drinks";
            SqlParameter[] sqlParameters = new SqlParameter[0];
            return ReadTables(ExecuteSelectQuery(query, sqlParameters));
        }

        private List<Drink> ReadTables(DataTable dataTable)
        {
            List<Drink> drinks = new List<Drink>();

            if (dataTable == null)
                throw new Exception("Datatable is leeg");

            foreach (DataRow dr in dataTable.Rows)
            {
                Drink drink = new Drink()
                {
                    DrinkID = (int)dr["DrinkID"],
                    DrinkName = (string)dr["DrinkName"],
                };
                drinks.Add(drink);
            }
            if (drinks.Count == 0)
                throw new Exception("There are no drinks");

            return drinks;
        }

        
        
    }
}
