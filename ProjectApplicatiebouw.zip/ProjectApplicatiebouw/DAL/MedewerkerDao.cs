﻿using Model;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class MedewerkerDao : BaseDao
    {
        private SqlConnection dbConnection;

        // Maak verbinding met de database
        public MedewerkerDao()
        {
            string connString = ConfigurationManager.ConnectionStrings["ChapeauDatabase"].ConnectionString;
            dbConnection = new SqlConnection(connString);
        }

        // Lees de medewerkers uit de database
        private List<Medewerker> ReadMedewerkers(DataTable dataTable)
        {
            List<Medewerker> medewerkers = new List<Medewerker>();

            if (dataTable == null)
                throw new Exception("Datatable is leeg");

            foreach (DataRow dr in dataTable.Rows)
            {
                Medewerker medewerker = new Medewerker()
                {
                    MedewerkerNummer = (int)dr["MedewerkerNummer"],
                    Naam = (string)dr["Naam"],
                    Functie = (string)dr["Functie"]
                   
                };
                medewerkers.Add(medewerker);
            }

            if (medewerkers.Count == 0)
                throw new Exception("Er zijn geen medewerkers gevonden");

            return medewerkers;
        }

        // Haal alle medewerkers op uit de database
        public List<Medewerker> GetAllMedewerkers()
        {
            string query = "SELECT MedewerkerNummer, Naam, Functie FROM Medewerker";
            SqlParameter[] sqlParameters = new SqlParameter[0];
            return ReadMedewerkers(ExecuteSelectQuery(query, sqlParameters));
        }

        // Voeg een nieuwe medewerker toe aan de database
        public void AddMedewerker(Medewerker medewerker)
        {
            string query = "INSERT INTO Medewerker (MedewerkerNummer, Naam, Functie) " +
                           "VALUES (@MedewerkerNummer, @Naam, @Functie)";
            try
            {
                dbConnection.Open();
                SqlCommand command = new SqlCommand(query, dbConnection);
                command.Parameters.AddWithValue("@MedewerkerNummer", medewerker.MedewerkerNummer);
                command.Parameters.AddWithValue("@Naam", medewerker.Naam);
                command.Parameters.AddWithValue("@Functie", medewerker.Functie);
                command.ExecuteNonQuery();
            }
            catch
            {
                throw new Exception("Kan geen verbinding maken met de database");
            }
            finally
            {
                dbConnection.Close();
            }
        }
    }
}
