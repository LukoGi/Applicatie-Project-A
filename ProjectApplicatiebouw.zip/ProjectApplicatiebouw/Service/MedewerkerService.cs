﻿using DAL;
using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Service
{
    public class MedewerkerService : MedewerkerDao
    {
        private MedewerkerDao medewerkerDao;

        public MedewerkerService()
        {
            medewerkerDao = new MedewerkerDao();
        }

        public List<Medewerker> GetMedewerkers()
        {
            return medewerkerDao.GetAllMedewerkers();
        }

        public void AddMedewerker(Medewerker medewerker)
        {
            medewerkerDao.AddMedewerker(medewerker);
        }

        // Add other methods for updating, deleting, etc.
    }
}
