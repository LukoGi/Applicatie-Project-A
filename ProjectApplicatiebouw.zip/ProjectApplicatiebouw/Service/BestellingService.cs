﻿using DAL;
using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Service
{
    public class BestellingService : BestellingDao
    {
        private BestellingDao bestellingdb;

        public BestellingService()
        {
            bestellingdb = new BestellingDao();
        }

        public List<Bestelling> GetBestellingen()
        {
            return bestellingdb.GetAllBestellingen();
        }

        public void AddBestelling(Bestelling bestelling)
        {
            bestellingdb.AddBestelling(bestelling);
        }

        // Voeg hier andere methoden toe voor het bijwerken, verwijderen, etc.
    }

}
