﻿using DAL;
using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Service
{
    public class TafelsService : TafelsDao
    {
        private TafelsDao tafelsdb;

        public TafelsService()
        {
            tafelsdb = new TafelsDao();
        }

        public List<Tafels> GetTafels()
        {
            return tafelsdb.GetAllTafels();
        }

        // Voeg hier andere methoden toe voor het bijwerken, verwijderen, etc.
    }

}
