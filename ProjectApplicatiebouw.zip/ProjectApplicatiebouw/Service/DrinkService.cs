﻿using DAL;
using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Service
{
    public class DrinkService : DrinksDao
    {
        private DrinksDao drinksdb;
        DrinksDao drinksDao = new DrinksDao();

        public DrinkService()
        {
            drinksdb = new DrinksDao();
        }

        public List<Drink> GetDrinks()
        {
            return drinksdb.GetAllDrinks();
        }
    }
}
