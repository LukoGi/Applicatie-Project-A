﻿using DAL;
using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Service
{
    public class DinerHoofdgerechtenService : DinerHoofdgerechtenDao
    {
        private DinerHoofdgerechtenDao dinerHoofdgerechtendb;

        public DinerHoofdgerechtenService()
        {
            dinerHoofdgerechtendb = new DinerHoofdgerechtenDao();
        }

        public List<DinerHoofdgerechten> GetDinerHoofdgerechten()
        {
            return dinerHoofdgerechtendb.GetAllDinerHoofdgerechten();
        }
    }
}
